from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone # Added for DateTimeField defaults
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=15, default='')

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()

class BankAccount(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    account_number = models.CharField(max_length=20)
    balance = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.account_number

class Transaction(models.Model):
    bank_account = models.ForeignKey(BankAccount, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(default=timezone.now) # Changed from date to timestamp
    description = models.CharField(max_length=100, blank=True, null=True)
    merchant = models.CharField(max_length=255, blank=True, null=True)
    original_description = models.TextField(blank=True, null=True)
    transaction_type = models.CharField(max_length=10, blank=True, null=True) # 'Debit' or 'Credit'
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    category = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return self.merchant or self.description or self.original_description or f"Transaction for {self.amount}"

class Alert(models.Model):
    PERIOD_CHOICES = [
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    category = models.CharField(max_length=100) # Category to monitor
    threshold_amount = models.DecimalField(max_digits=10, decimal_places=2) # Max spending in period
    period = models.CharField(max_length=10, choices=PERIOD_CHOICES) # Weekly or Monthly
    is_active = models.BooleanField(default=True)
    last_checked = models.DateTimeField(blank=True, null=True) # When the alert was last checked

    def __str__(self):
        return f"{self.user.username}'s {self.period} {self.category} Alert (${self.threshold_amount})"

class Budget(models.Model):
    BUDGET_TYPE_CHOICES = [
        ('spending', 'Spending Budget'),
        ('savings', 'Savings Goal'),
    ]
    PERIOD_CHOICES = [
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('yearly', 'Yearly'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    type = models.CharField(max_length=10, choices=BUDGET_TYPE_CHOICES)
    target_amount = models.DecimalField(max_digits=10, decimal_places=2)
    period = models.CharField(max_length=10, choices=PERIOD_CHOICES)
    category = models.CharField(max_length=100, blank=True, null=True) # For category-specific spending budgets
    
    # Track when the budget was set/last updated
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        # Ensure only one budget of a certain type/period/category per user
        unique_together = ('user', 'type', 'period', 'category') 

    def __str__(self):
        if self.category:
            return f"{self.user.username}'s {self.period} {self.category} {self.type} Budget ({self.target_amount})"
        return f"{self.user.username}'s {self.period} {self.type} Budget ({self.target_amount})"