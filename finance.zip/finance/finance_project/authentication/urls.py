from django.urls import path
from . import views

urlpatterns = [
    path('signin/', views.signin, name='signin'),
    path('login/', views.login, name='login'),
    path('reset_password/', views.reset_password, name='reset_password'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('logout/', views.logout_view, name='logout'),
    path('upload-transactions/', views.upload_transactions, name='upload_transactions'),
    path('create-alert/', views.create_alert, name='create_alert'),
    path('manage-budgets/', views.manage_budgets, name='manage_budgets'), # Added this line
]