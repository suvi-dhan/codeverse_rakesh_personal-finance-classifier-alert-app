import os
import io
import csv
import re
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from dateutil.relativedelta import relativedelta

from django.db import transaction
from django.db.models import Sum
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.utils import timezone

from .models import Profile, BankAccount, Transaction, Alert, Budget


def signin(request):
    """
    Handles user sign-in (registration).
    """
    if request.method == 'POST':
        username = request.POST['username']
        phone = request.POST['phone']
        password = request.POST['password']

        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists')
            return render(request, 'signin.html', {'error': 'Username already exists'})
        
        if Profile.objects.filter(phone=phone).exists():
            messages.error(request, 'Phone number already registered')
            return render(request, 'signin.html', {'error': 'Phone number already registered'})

        user = User.objects.create_user(username=username, password=password)
        user.profile.phone = phone
        user.save()

        # Create a mock bank account (transactions now handled by CSV import)
        BankAccount.objects.create(user=user, account_number='1234567890', balance=Decimal('0.00')) # Start with 0 balance
        
        messages.success(request, 'Sign in successful. Please log in.')
        return redirect('login')
    return render(request, 'signin.html')

def login(request):
    """
    Handles user login.
    """
    if request.method == 'POST':
        username = request.POST.get('username')
        phone = request.POST.get('phone')
        password = request.POST.get('password')

        user = None
        if phone:
            try:
                profile = Profile.objects.get(phone=phone)
                user = authenticate(request, username=profile.user.username, password=password)
            except Profile.DoesNotExist:
                pass

        if user is None and username:
            user = authenticate(request, username=username, password=password)

        if user is not None:
            auth_login(request, user)
            messages.success(request, 'Login successful.')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid credentials')
            return render(request, 'login.html')

    return render(request, 'login.html')

def reset_password(request):
    """
    Handles password reset requests.
    """
    if request.method == 'POST':
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')

        if new_password == confirm_password:
            # Placeholder: In a real app, you'd verify the user first (e.g., via email token)
            # For now, just a success message
            messages.success(request, 'Password reset successful (if user exists and verified).')
            return redirect('login')
        else:
            messages.error(request, 'Passwords do not match.')
    return render(request, 'reset_password.html')

@login_required
def home(request):
    return redirect('dashboard')

@login_required
def create_alert(request):
    """
    Handles creating and editing overspending alerts.
    """
    user_categories = Transaction.objects.filter(
        bank_account__user=request.user
    ).exclude(category__isnull=True).values_list('category', flat=True).distinct()

    if request.method == 'POST':
        category = request.POST.get('category')
        threshold_amount_str = request.POST.get('threshold_amount')
        period = request.POST.get('period')

        if not category or not threshold_amount_str or not period:
            messages.error(request, 'All fields are required.')
            return render(request, 'create_alert.html', {'available_categories': user_categories})

        try:
            threshold_amount = Decimal(threshold_amount_str)
            if threshold_amount <= 0:
                messages.error(request, 'Threshold amount must be positive.')
                return render(request, 'create_alert.html', {'available_categories': user_categories})
        except InvalidOperation:
            messages.error(request, 'Invalid threshold amount.')
            return render(request, 'create_alert.html', {'available_categories': user_categories})
        
        if period not in [p[0] for p in Alert.PERIOD_CHOICES]:
            messages.error(request, 'Invalid period selected.')
            return render(request, 'create_alert.html', {'available_categories': user_categories})
        
        # Check if an alert for this category and period already exists for the user
        existing_alert = Alert.objects.filter(
            user=request.user,
            category=category,
            period=period
        ).first()

        if existing_alert:
            messages.info(request, f'Alert for {category} ({period}) already exists. Updating it.')
            existing_alert.threshold_amount = threshold_amount
            existing_alert.is_active = True
            existing_alert.save()
        else:
            Alert.objects.create(
                user=request.user,
                category=category,
                threshold_amount=threshold_amount,
                period=period,
                is_active=True
            )
        messages.success(request, f'Alert for {category} ({period}) set to ₹{threshold_amount}.')
        return redirect('dashboard')
    
    context = {
        'available_categories': list(user_categories),
    }
    return render(request, 'create_alert.html', context)


@login_required
def manage_budgets(request):
    """
    Handles displaying existing budgets and the form for creating/editing.
    """
    user_budgets = Budget.objects.filter(user=request.user)
    available_categories = Transaction.objects.filter(
        bank_account__user=request.user
    ).exclude(category__isnull=True).values_list('category', flat=True).distinct()

    editing_budget = None
    edit_id = request.GET.get('edit_id')
    if edit_id:
        try:
            editing_budget = Budget.objects.get(id=int(edit_id), user=request.user)
        except (Budget.DoesNotExist, ValueError): # Catch ValueError if edit_id is not int
            messages.error(request, 'Budget for editing not found or invalid ID.')

    if request.method == 'POST':
        budget_id = request.POST.get('budget_id')
        budget_type = request.POST.get('budget_type')
        category = request.POST.get('category')
        target_amount_str = request.POST.get('target_amount')
        period = request.POST.get('period')

        if not budget_type or not target_amount_str or not period:
            messages.error(request, 'All required fields must be filled.')
            # Re-render form with context if validation fails for POST
            context = {
                'user_budgets': user_budgets,
                'available_categories': list(available_categories),
                'editing_budget': editing_budget, # Keep editing budget if it was there
            }
            return render(request, 'manage_budgets.html', context)

        try:
            target_amount = Decimal(target_amount_str)
            if target_amount <= 0:
                messages.error(request, 'Target amount must be positive.')
                context = {
                    'user_budgets': user_budgets,
                    'available_categories': list(available_categories),
                    'editing_budget': editing_budget,
                }
                return render(request, 'manage_budgets.html', context)
        except InvalidOperation:
            messages.error(request, 'Invalid target amount.')
            context = {
                'user_budgets': user_budgets,
                'available_categories': list(available_categories),
                'editing_budget': editing_budget,
            }
            return render(request, 'manage_budgets.html', context)
        
        # Validate period and type from model choices
        if period not in [p[0] for p in Budget.PERIOD_CHOICES]:
            messages.error(request, 'Invalid period selected.')
            context = {
                'user_budgets': user_budgets,
                'available_categories': list(available_categories),
                'editing_budget': editing_budget,
            }
            return render(request, 'manage_budgets.html', context)
        if budget_type not in [b[0] for b in Budget.BUDGET_TYPE_CHOICES]:
            messages.error(request, 'Invalid budget type selected.')
            context = {
                'user_budgets': user_budgets,
                'available_categories': list(available_categories),
                'editing_budget': editing_budget,
            }
            return render(request, 'manage_budgets.html', context)

        # Category is only required for 'spending' budgets
        if budget_type == 'spending' and not category:
            messages.error(request, 'Category is required for spending budgets.')
            context = {
                'user_budgets': user_budgets,
                'available_categories': list(available_categories),
                'editing_budget': editing_budget,
            }
            return render(request, 'manage_budgets.html', context)
        
        # Clear category for 'savings' budgets if provided by mistake
        if budget_type == 'savings':
            category = None

        if budget_id:
            # Update existing budget
            try:
                budget = Budget.objects.get(id=int(budget_id), user=request.user)
                budget.type = budget_type
                budget.category = category # Set to None if savings
                budget.target_amount = target_amount
                budget.period = period
                budget.save()
                messages.success(request, f'Budget "{budget.type}" updated successfully.')
            except (Budget.DoesNotExist, ValueError):
                messages.error(request, 'Budget not found or invalid ID for update.')
        else:
            # Create new budget
            # Check for unique constraint violation manually for better feedback
            filter_kwargs = {'user': request.user, 'type': budget_type, 'period': period}
            if budget_type == 'spending':
                filter_kwargs['category'] = category
            else: # savings
                filter_kwargs['category'] = None # Ensure category is None for savings budgets uniqueness

            if Budget.objects.filter(**filter_kwargs).exists():
                category_display = f"for category '{category}'" if category else ""
                messages.error(request, f"A {budget_type} budget {category_display} for the {period} already exists.")
                return redirect('manage_budgets')

            Budget.objects.create(
                user=request.user,
                type=budget_type,
                category=category, # Set to None if savings
                target_amount=target_amount,
                period=period
            )
            messages.success(request, 'Budget created successfully.')
        return redirect('manage_budgets')
    
    # GET request: display form and existing budgets
    user_budgets = Budget.objects.filter(user=request.user).order_by('type', 'period', 'category')
    available_categories = Transaction.objects.filter(
        bank_account__user=request.user
    ).exclude(category__isnull=True).values_list('category', flat=True).distinct()
    
    editing_budget = None
    edit_id = request.GET.get('edit_id')
    if edit_id:
        try:
            editing_budget = Budget.objects.get(id=int(edit_id), user=request.user)
        except (Budget.DoesNotExist, ValueError):
            messages.error(request, 'Budget for editing not found or invalid ID.')

    context = {
        'user_budgets': user_budgets,
        'available_categories': list(available_categories),
        'editing_budget': editing_budget
    }
    return render(request, 'manage_budgets.html', context)

def check_overspending_alerts(user):
    triggered_alerts_messages = []
    
    active_alerts = Alert.objects.filter(user=user, is_active=True)
    for alert in active_alerts:
        end_date = timezone.now().date()
        if alert.period == 'weekly':
            start_date = end_date - timedelta(days=7)
        elif alert.period == 'monthly':
            start_date = end_date - relativedelta(months=1)
        else:
            continue # Should not happen with choices

        # Sum spending for the category in the period
        # Note: assuming negative amounts are expenses. Adjust if needed.
        total_spending = Transaction.objects.filter(
            bank_account__user=user,
            category=alert.category,
            timestamp__date__range=[start_date, end_date], # Changed to timestamp__date__range
            amount__lt=0 # Only consider expenses
        ).aggregate(Sum('amount'))['amount__sum']

        # Ensure total_spending is non-negative for comparison
        total_spending = abs(total_spending) if total_spending is not None else Decimal('0.00')

        if total_spending > alert.threshold_amount:
            triggered_alerts_messages.append(
                f"Alert: You have spent ₹{total_spending:.2f} in '{alert.category}' this {alert.period}, exceeding your limit of ₹{alert.threshold_amount:.2f}!"
            )
        
        # Update last_checked for the alert
        alert.last_checked = timezone.now()
        alert.save() # This might be better done in a separate background task for performance

    return triggered_alerts_messages

@login_required
def dashboard(request):
    bank_account = BankAccount.objects.get(user=request.user)
    transactions = Transaction.objects.filter(bank_account=bank_account).order_by('-timestamp') # Order by timestamp
    
    # Check for triggered alerts
    triggered_alerts = check_overspending_alerts(request.user)

    # Calculate spending by category for the last 30 days
    today = date.today()
    thirty_days_ago = today - timedelta(days=30)

    spending_by_category = Transaction.objects.filter(
        bank_account__user=request.user,
        timestamp__date__range=[thirty_days_ago, today], # Changed to timestamp__date__range
        amount__lt=0, # Only consider expenses
        category__isnull=False
    ).values('category').annotate(total_spent=Sum('amount')).order_by('category')
    
    # Convert negative total_spent to positive for display
    # And format for display
    formatted_spending_by_category = [
        {
            'category': item['category'],
            'total_spent': abs(item['total_spent'])
        } for item in spending_by_category
    ]

    # Calculate total spent balance (expenses) and saved balance (current account balance)
    # Spent Balance (total expenses for the last 30 days)
    total_spent_for_period = Transaction.objects.filter(
        bank_account__user=request.user,
        timestamp__date__range=[thirty_days_ago, today],
        transaction_type='Debit' # Only consider debits/expenses
    ).aggregate(total_amount=Sum('amount'))['total_amount'] or Decimal('0.00')
    
    # Saved Balance (current overall balance)
    # For now, we use bank_account.balance. In a real system, this would be updated by transactions.
    total_saved_balance = bank_account.balance

    context = {
        'bank_account': bank_account,
        'transactions': transactions,
        'phone': request.user.profile.phone,
        'triggered_alerts': triggered_alerts, # Pass alerts to template
        'spending_by_category': formatted_spending_by_category, # Pass spending insights
        'current_spent_amount': abs(total_spent_for_period), # Total expenses as a positive value
        'current_saved_amount': total_saved_balance, # Current account balance
        'user_budgets': Budget.objects.filter(user=request.user).order_by('type', 'period', 'category') # Pass budgets to dashboard
    }
    return render(request, 'dashboard.html', context)

def logout_view(request):
    logout(request)
    return redirect('login')

# Helper function for transaction classification (MVP - rule-based)
def classify_transaction(description, amount):
    description_lower = description.lower()
    
    # Define simple keyword-based rules for MVP
    if "salary" in description_lower or "payroll" in description_lower:
        return "Income"
    elif "rent" in description_lower or "housing" in description_lower:
        return "Housing"
    elif "groceries" in description_lower or "supermarket" in description_lower or "lidl" in description_lower or "tesco" in description_lower:
        return "Groceries"
    elif "coffee" in description_lower or "starbucks" in description_lower or "cafe" in description_lower:
        return "Coffee"
    elif "gas" in description_lower or "petrol" in description_lower:
        return "Transport"
    elif "subscription" in description_lower or "netflix" in description_lower or "spotify" in description_lower:
        return "Subscriptions"
    elif "transfer" in description_lower and amount < 0:
        return "Transfer Out"
    elif "transfer" in description_lower and amount > 0:
        return "Transfer In"
    else:
        return "Uncategorized" # Default category

import csv
from django.core.files.storage import FileSystemStorage
import io # To handle in-memory file operations
from decimal import Decimal # For handling monetary values
from django.db import transaction # For atomic operations
from datetime import datetime # For date parsing

@login_required
def upload_transactions(request):
    if request.method == 'POST' and request.FILES['csv_file']:
        csv_file = request.FILES['csv_file']

        # Basic validation: Check if it's a CSV file
        if not csv_file.name.endswith('.csv'):
            messages.error(request, 'Please upload a CSV file.')
            return redirect('dashboard')
        
        # Read the CSV file content and decode with 'utf-8-sig' to handle BOM
        data_set = csv_file.read().decode('utf-8-sig') # <-- Changed to utf-8-sig
        io_string = io.StringIO(data_set)
        
        # Read all lines into a list first
        csv_reader = csv.reader(io_string, delimiter=',', quotechar='"')
        all_rows = list(csv_reader)

        # Ensure there are enough rows for at least a header and one transaction group (2 data rows)
        if len(all_rows) < 3: # Header + Row1 + Row2
            messages.error(request, 'CSV file is too short to contain valid transaction data.')
            return redirect('dashboard')

        imported_count = 0
        current_bank_account = BankAccount.objects.get(user=request.user)

        try:
            with transaction.atomic(): # Ensure all or none transactions are saved
                i = 1 # Start processing from the first data row, skipping header (all_rows[0])
                while i < len(all_rows):
                    row1 = all_rows[i] # Main transaction row
                    
                    # Skip empty separator rows (like ,,,₹) or entirely empty rows
                    if not any(cell.strip() for cell in row1) or (len(row1) > 3 and row1[3].strip() == '₹'):
                        i += 1
                        continue
                    
                    # Ensure row1 has enough columns
                    if len(row1) < 4: # Date, Transaction Details (Main), Type, Amount
                        messages.warning(request, f"Skipped incomplete main transaction row: {row1}. Expected at least 4 columns.")
                        i += 1
                        continue

                    date_str = row1[0].strip()
                    original_desc_main = row1[1].strip()
                    transaction_type_str = row1[2].strip()
                    amount_str = row1[3].strip()

                    # Expect next row to be sub-detail row
                    i += 1
                    if i >= len(all_rows): # End of file
                        messages.warning(request, f"Skipped transaction starting with '{row1}' due to missing time/details row at end of file.")
                        break # Exit loop
                    
                    row2 = all_rows[i] # Sub-detail row

                    # If row2 is an empty separator or fully empty, it's malformed
                    if not any(cell.strip() for cell in row2) or (len(row2) > 3 and row2[3].strip() == '₹'):
                        messages.warning(request, f"Skipped transaction starting with '{row1}' due to malformed time/details row or misplaced separator: {row2}.")
                        # Try to advance past separator to find next transaction if possible, but skip current logical transaction
                        i += 1
                        continue

                    if len(row2) < 2: # Time and extended details expected
                        messages.warning(request, f"Skipped transaction starting with '{row1}' due to incomplete time/details row: {row2}. Expected at least 2 columns.")
                        i += 1
                        continue
                    
                    time_str = row2[0].strip() # Time is in first column of second row
                    original_desc_sub = row2[1].strip() if len(row2) > 1 else "" # Extended details

                    try:
                        # Combine date and time
                        # Parse Date (e.g., "Nov 19, 2025") - remove quotes first
                        parsed_date = None
                        date_formats = ['"%b %d, %Y"', '%b %d, %Y', '%Y-%m-%d', '%m/%d/%Y', '%d-%m-%Y', '%d/%m/%Y'] # Try various date formats
                        for fmt in date_formats:
                            try:
                                parsed_date = datetime.strptime(date_str.replace('"', ''), fmt).date()
                                break
                            except ValueError:
                                continue
                        if not parsed_date:
                            raise ValueError(f"Could not parse date format for '{date_str}'")

                        # Parse Time (e.g., "04:27 pm", "16:27") - try common formats
                        parsed_time = None
                        time_formats = ['%I:%M %p', '%H:%M', '%I:%M:%S %p', '%H:%M:%S', '%H:%M %p'] # Added %H:%M %p for 24-hour with AM/PM
                        for fmt in time_formats:
                            try:
                                parsed_time = datetime.strptime(time_str, fmt).time()
                                break
                            except ValueError:
                                continue
                        
                        if not parsed_time:
                             raise ValueError(f"Could not parse time format for '{time_str}'")

                        trans_timestamp = datetime.combine(parsed_date, parsed_time)
                        
                        # Full original description
                        original_desc = f"{original_desc_main} {original_desc_sub}".strip()
                        merchant_name = original_desc # For MVP, merchant is initially same as original description

                        # Amount handling: replace currency symbols, commas, and strip whitespace
                        trans_amount = Decimal(amount_str.replace('$', '').replace('₹', '').replace(',', '').strip())

                        # Determine transaction_type and adjust amount sign
                        actual_transaction_type = None
                        if transaction_type_str.lower() == 'debit':
                            actual_transaction_type = 'Debit'
                            if trans_amount > 0: trans_amount *= -1 # Ensure debit is negative
                        elif transaction_type_str.lower() == 'credit':
                            actual_transaction_type = 'Credit'
                            if trans_amount < 0: trans_amount *= -1 # Ensure credit is positive
                        else: # Fallback based on amount if type column is unclear
                            if trans_amount < 0:
                                actual_transaction_type = 'Debit'
                            else:
                                actual_transaction_type = 'Credit' # Default to credit if positive

                        # Classify transaction
                        category_name = classify_transaction(original_desc, trans_amount)

                        # Create Transaction object
                        Transaction.objects.create(
                            bank_account=current_bank_account,
                            timestamp=trans_timestamp,
                            original_description=original_desc,
                            merchant=merchant_name,
                            transaction_type=actual_transaction_type,
                            amount=trans_amount,
                            category=category_name,
                        )
                        imported_count += 1
                    except (ValueError, IndexError, InvalidOperation) as e: # Catch InvalidOperation for Decimal parsing
                        messages.warning(request, f"Skipped transaction group starting with '{row1}' due to parsing error: {e}")
                    
                    i += 1 # Move to the next potential main transaction row

            messages.success(request, f'{imported_count} transactions imported successfully.')
            return redirect('dashboard')

        except Exception as e:
            messages.error(request, f'An unexpected error occurred during import: {e}')
            return redirect('dashboard')
    
    messages.error(request, 'Please select a file to upload.')
    return redirect('dashboard')